<?php
include_once "global.php";
	
	session_start();		//start php session
	session_regenerate_id(true);		//regenerate session and delete the old session

?>