<?php
//*************************define all the variables for login
$server = "localhost";
$user = "root";
$password = "aoyama0118";
$dbName = "lib_system";
$userid;

?>