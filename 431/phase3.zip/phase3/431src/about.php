<?php
include "header.php";

//**********************************print the explanation
print <<< eot
	<HTML>
		<HEAD>
		</HEAD>
		<BODY>
		<div class = "about">
			<CENTER>
				<FONT SIZE = "8">
					Library Hours<BR>
				</FONT>
				<FONT SIZE = "5">
					Monday - Friday	: 7:00am - 1:00am<BR>
					Saturday		: 12:00pm - 9:00pm<BR>
					Sunday			: Closed<BR>
			</CENTER>
		</div>
		</BODY>
	</HTML>
	

eot;

?>