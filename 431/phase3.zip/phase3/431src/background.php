<?php
print <<< eot1

	<HTML>

		<HEAD>
		<TITLE>MY MONGO MARIA</TITLE>
		</HEAD>
		<BODY BGCOLOR = "AliceBlue">
		<BODY>
		<CENTER>
			<IMG SRC = "image/logo.png">
			<BR><BR>
		</CENTER>
		</BODY>
		</HTML>
eot1;
?>